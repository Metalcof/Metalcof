<?php
require 'database.php';
//session_start();
$con = new Database();
$pdo = $con->conectar();
//$item=$_SESSION['key'];
//$usuario=$_SESSION['user'];

$item_agregado = $_POST["item_agregado"];
//$item_agregado = "PINTURA MARTILLADA - GRIS ACORAZADO";

$encontrar_item = "SELECT descripcion_item, codigo_item FROM `items` ORDER BY descripcion_item ASC";
//$resultado = $pdo->query($item_encontrado);
$result = $pdo->query($encontrar_item);


$html = "";

while ($row = $result->fetch(PDO::FETCH_ASSOC)) {	
	//$html .= "<option value=".$row["descripcion_item"]." - ".$row["codigo_item"].">".$row["descripcion_item"]." - ".$row["codigo_item"]."</option>";
	$html .= "<option value=".$row["codigo_item"]." - ".$row["descripcion_item"].">".$row["codigo_item"]." - ".$row["descripcion_item"]."</option>";

}

echo json_encode($html, JSON_UNESCAPED_UNICODE);

/*
$consulta_suma = "UPDATE pedidos SET acumulado = (SELECT sum(valor_producto) from pedidos WHERE cedula='$cedula')";
$resul_suma = $pdo->query($consulta_suma);


$query = "SELECT codigo_producto, descripcion_producto,cantidad_pedido, valor_producto FROM pedidos_c2 WHERE cedula ='$cedula'";
$result = $pdo->query($query);
$adicionar = " ";

while ($row = $result->fetch(PDO::FETCH_ASSOC)) {	


	//$html1 .= "<li>". $row["descripcion"] . $row["valor_uni"] . "</li>";
	//$html .= "<li>". $row["descripcion"]."&&</li>". $row["valor_uni"];
	$adicionar.= "<tr><td>". $row["codigo_producto"]."</td><td>". $row["descripcion_producto"]."</td><td>". $row["cantidad_pedido"]."</td><td>".$row["valor_producto"]."</td>
	<td><button type=\"button\" style=\"background-color: rgb(141,174,95);\" class=\"btn btn-primary btn-sm\" onclick=\"eliminarItem('".$row["codigo_producto"]."')\">Eliminar</button></td></tr>";
	
}


echo json_encode($adicionar, JSON_UNESCAPED_UNICODE);
*/
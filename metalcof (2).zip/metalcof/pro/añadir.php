<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<div class="row" id="nueva_estufa">
            <div class="container">
                <form action="pro/nuevaestufa.php" method="POST" name="formu" id="formu" enctype="multipart/form-data">
                        <div class="row form-group" style="padding-top: 10px;">
                            <div class="col-md-2" style="text-align: end;">
                                <label for="inputname"  >Código Estufa</label>
                            </div>
                            <div class="col-6">
                                <input type="text" class="form-control mt-1" id="codigo_item" name="codigo_item" placeholder="" onkeyup="mayusculas(this);" required>
                            </div> 
                        </div>
                        <div class="row form-group" style="padding-top: 10px;">
                            <div class="col-md-2" style="text-align: end;">
                                <label for="inputname">Nombre Estufa</label>
                            </div>
                            <div class="col-6">
                                <input type="text" class="form-control mt-1" id="descripcion_item" name="descripcion_item" placeholder="" onkeyup="mayusculas(this);" required>
                            </div> 
                        </div>
                        <div class="row form-group" style="padding-top: 10px;">
                            <div class="col-2" style="text-align: end;">
                                <label for="inputname">Mano de Obra</label>
                            </div>
                            <div class="col-6">
                                <input type="text" class="form-control mt-1" id="materiaprima_pieza" name="materiaprima_pieza" placeholder="" onkeyup="mayusculas(this);" required>
                            </div> 
                        </div>
                        <div class="row form-group" style="padding-top: 10px;">
                            <div class="col-2" style="text-align: end;">
                                <label for="campo">Añadir Item</label>
                            </div>
                            <div class="col-6">
                                <form action="" method="post" autocomplete="off">
                                    <p>
                                        <input type="text" name="campo" id="campo" class="form-control mt-1" placeholder="" onkeyup="mayusculas(this);" required>
                                    </p>
                                </form>
                            </div> 
                        </div>
                        <div class="row form-group" style="padding-top: 10px;">
                            <div class="col-2" style="text-align: end;">
                                <label for="inputname">Cantidad de Items</label>
                            </div>
                            <div class="col-6">
                                <input type="text" class="form-control mt-1" id="costo_unitario_jm" name="costo_unitario_jm" placeholder="" onkeyup="mayusculas(this);" required>
                            </div> 
                        </div>
                        <div class="row form-group" style="padding-top: 10px;">
                            <div class="col-2" style="text-align: end;">
                                <label for="inputname">Costo</label>
                            </div>
                            <div class="col-6">
                                <input type="text" class="form-control mt-1" id="costos_totales" name="costos_totales" placeholder="" onkeyup="mayusculas(this);" required>
                            </div> 
                        </div>
                        <div class="row form-group" style="padding-top: 10px;">
                            <div class="col-2" style="text-align: end;">
                                <label for="inputname">Iva</label>
                            </div>
                            <div class="col-6">
                                <input type="text" class="form-control mt-1" id="cantidad_estufas" name="cantidad_estufas" placeholder="" onkeyup="mayusculas(this);" required>
                            </div> 
                        </div>
                        <div class="row form-group" style="padding-top: 10px;">
                            <div class="col-2" style="text-align: end;">
                                <label for="inputname">Costo Total</label>
                            </div>
                            <div class="col-6">
                                <input type="text" class="form-control mt-1" id="total_cantidad" name="total_cantidad" placeholder="" onkeyup="mayusculas(this);" required>
                            </div> 
                        </div>
                        <div class="row" form-group" style="padding-top: 10px;">
                            <div class="col-md-2" style="text-align: end;">
                                
                            </div>
                            <div class="col-6" > 
                                <button  class="form-control mt-1" type="submit" value="" style="height: 30px;width: 100px; background-color: rgb(176, 176, 246);">Guardar</button>
                            </div>
                        </div>
                </form>
            </div>
        </div><br><br>   
    </div>
</body>
</html>
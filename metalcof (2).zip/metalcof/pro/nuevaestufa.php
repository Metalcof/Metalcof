<?php
require 'database.php';
//session_start();
$con = new Database();
$pdo = $con->conectar();
//$item=$_SESSION['key'];
//$usuario=$_SESSION['user'];

$codigo_estufa = $_POST["codigo_estufa"];
$nombre_estufa = $_POST["nombre_estufa"];
$item_agregado = $_POST["item_agregado"];
$anadir_cantidad_item = $_POST["anadir_cantidad_item"];
$valor_mano_obra = $_POST["valor_mano_obra"];
$valorestufa_noiva = $_POST["valorestufa_noiva"];
$iva = $_POST["iva"];
$valor_total_estufa = $_POST["valor_total_estufa"];
$insertar_item = "INSERT INTO nuevaestufa (codigo_estufa, nombre_estufa, item_agregado, anadir_cantidad_item, valor_mano_obra, valorestufa_noiva, iva, valor_total_estufa) VALUES
        ('$codigo_estufa', '$nombre_estufa','$item_agregado','$anadir_cantidad_item','$valor_mano_obra', '$valorestufa_noiva', '$iva', '$valor_total_estufa')";
$resultado = $pdo->query($insertar_item);

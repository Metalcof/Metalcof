-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 16-10-2024 a las 02:17:57
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `estufas`
--
CREATE DATABASE IF NOT EXISTS `estufas` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `estufas`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `Clie_ID` int(11) NOT NULL,
  `Clie_Nombre` varchar(50) NOT NULL,
  `Clie_Direccion` char(30) NOT NULL,
  `Clie_Ciudad` varchar(20) NOT NULL,
  `Clie_Pais` varchar(20) NOT NULL,
  `Clie_Regimen` varchar(20) NOT NULL,
  `Clie_CodigoPostal` varchar(20) NOT NULL,
  `Clie_Email` varchar(20) NOT NULL,
  `Clie_Telefono` tinyint(20) NOT NULL,
  `Clie_NumeroID` varchar(20) NOT NULL,
  `Clie_FechaCompra` datetime NOT NULL,
  `Clie_Activo` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`Clie_ID`, `Clie_Nombre`, `Clie_Direccion`, `Clie_Ciudad`, `Clie_Pais`, `Clie_Regimen`, `Clie_CodigoPostal`, `Clie_Email`, `Clie_Telefono`, `Clie_NumeroID`, `Clie_FechaCompra`, `Clie_Activo`) VALUES
(1, 'Ipus ', 'Calle 69 #2-76', 'Ciudad de México', 'México', 'General', '01000', 'juan.perez@mail.com', 127, 'MXP123456', '2023-08-15 00:00:00', 1),
(2, 'Riqui Ricon', 'Av. Siempre Viva 456', 'Guadalajara', 'México', 'Simplificado', '44100', 'ana.lopez@mail.com', 127, 'MXG987654', '2023-08-20 00:00:00', 1),
(3, 'Carlos García', 'Calle Los Olivos 789', 'Monterrey', 'México', 'General', '64000', 'carlos.garcia@mail.c', 127, 'MXM654321', '2023-09-01 00:00:00', 1),
(4, 'María Fernández', 'Av. Reforma 101', 'Puebla', 'México', 'Simplificado', '72000', 'maria.fernandez@mail', 127, 'MXP654987', '2023-09-05 00:00:00', 0),
(5, 'Luis Gómez', 'Calle Los Robles 202', 'Querétaro', 'México', 'General', '76000', 'luis.gomez@mail.com', 127, 'MXQ321654', '2023-09-10 00:00:00', 1),
(6, 'Gabriela Ortiz', 'Av. Libertador 303', 'Cancún', 'México', 'Simplificado', '77500', 'gabriela.ortiz@mail.', 127, 'MXC123789', '2023-09-15 00:00:00', 0),
(7, 'Ricardo Ramírez', 'Calle Palma 404', 'León', 'México', 'General', '37000', 'ricardo.ramirez@mail', 127, 'MXL789321', '2023-09-20 00:00:00', 1),
(8, 'Laura Ruiz', 'Av. Las Palmas 505', 'Tijuana', 'México', 'Simplificado', '22000', 'laura.ruiz@mail.com', 127, 'MXT987321', '2023-09-25 00:00:00', 1),
(9, 'José Hernández', 'Calle Arboledas 606', 'Mérida', 'México', 'General', '97000', 'jose.hernandez@mail.', 127, 'MXM123654', '2023-09-30 00:00:00', 0),
(10, 'Fernanda Castillo', 'Av. Los Laureles 707', 'Toluca', 'México', 'Simplificado', '50000', 'fernanda.castillo@ma', 127, 'MXT321987', '2023-10-05 00:00:00', 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`Clie_ID`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `Clie_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- Base de datos: `metalcof`
--
CREATE DATABASE IF NOT EXISTS `metalcof` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `metalcof`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `items`
--

CREATE TABLE `items` (
  `item` int(11) NOT NULL COMMENT 'item del item',
  `codigo_item` varchar(10) NOT NULL COMMENT 'codigo de cada item',
  `descripcion_item` varchar(100) NOT NULL COMMENT 'descripción de cada item',
  `materiaprima_pieza` varchar(50) NOT NULL,
  `cantidad_material` float NOT NULL,
  `costo_unitario_jm` float NOT NULL,
  `unidad_medida` varchar(50) NOT NULL,
  `costos_totales` float NOT NULL,
  `cantidad_estufas` float NOT NULL,
  `total_cantidad` float NOT NULL,
  `valor_total_materiaprima` float NOT NULL,
  `asignar_estufa` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `items`
--

INSERT INTO `items` (`item`, `codigo_item`, `descripcion_item`, `materiaprima_pieza`, `cantidad_material`, `costo_unitario_jm`, `unidad_medida`, `costos_totales`, `cantidad_estufas`, `total_cantidad`, `valor_total_materiaprima`, `asignar_estufa`) VALUES
(1, 'G1', 'MARTILLADA GRIS ACORAZADO', '0.080', 0.25, 60, 'galon', 15, 7.8, 2, 8.5, 'estufa2'),
(2, 'E004', 'TORNILLO', '2', 100, 100, 'unidad', 10000, 1, 10000, 10000, 'estufa1'),
(3, '', '', '', 0, 0, '', 0, 0, 0, 0, ''),
(4, '', '', '', 0, 0, '', 0, 0, 0, 0, ''),
(5, '', '', '', 0, 0, '', 0, 0, 0, 0, ''),
(6, '', '', '', 0, 0, '', 0, 0, 0, 0, ''),
(7, '', '', '', 0, 0, '', 0, 0, 0, 0, ''),
(8, '', '', '', 0, 0, '', 0, 0, 0, 0, ''),
(9, '', '', '', 0, 0, '', 0, 0, 0, 0, ''),
(10, '', '', '', 0, 0, '', 0, 0, 0, 0, ''),
(11, '', '', '', 0, 0, '', 0, 0, 0, 0, ''),
(12, '1000', 'ANGULO', '2', 3, 60, 'gramos', 15, 1, 10000, 9000, 'estufa2'),
(13, 'd0023', 'ccartulina', '1', 3, 2500, 'metro', 7500, 3, 30, 40000, '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `nuevaestufa`
--

CREATE TABLE `nuevaestufa` (
  `codigo_estufa` varchar(50) NOT NULL,
  `nombre_estufa` varchar(50) NOT NULL,
  `item_agregado` varchar(100) NOT NULL,
  `anadir_cantidad_item` float NOT NULL,
  `valor_mano_obra` float NOT NULL,
  `valorestufa_noiva` float NOT NULL,
  `iva` float NOT NULL,
  `valor_total_estufa` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `nuevaestufa`
--

INSERT INTO `nuevaestufa` (`codigo_estufa`, `nombre_estufa`, `item_agregado`, `anadir_cantidad_item`, `valor_mano_obra`, `valorestufa_noiva`, `iva`, `valor_total_estufa`) VALUES
('E0033', 'PRUEBA', 'TF', 3, 45000, 30000, 59000, 90000),
('', '', '', 0, 0, 0, 0, 0),
('E003', 'PRUEBA', 'estufa2', 7.8, 6.65, 20, 2, 100),
('', '', '', 0, 0, 0, 0, 0),
('E00334', 'PRUEBA1', 'PINTURA', 7.87, 6.65055, 20, 2.5, 150),
('', '', '', 0, 0, 0, 0, 0),
('E00337', 'PRUEBA1', 'PINTURA', 7.87, 6.65055, 20, 2.5, 150),
('E00339', 'PRUEBA1', 'PINTURA', 7.87, 6.65055, 20, 2.5, 150),
('E00340', 'PRUEBA4', 'PINTURA', 7.8788, 88.89, 20, 2.899, 90000),
('', '', '', 0, 0, 0, 0, 0),
('E0034466', 'PRUEBA14', 'MARTILLADA', 7.8666, 6.65055, 20, 2, 22),
('E003', 'PRUEBA11', '1000', 7.87, 798.877, 30000, 2.5, 100),
('E003', 'PRUEBA11', '1000', 7.87, 798.877, 30000, 2.5, 100),
('ESTUFA4', 'ECOLOGICA100', '-', 3, 6.65, 680000, 120000, 800000),
('gfg', 'f', '', 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tabla_estufas`
--

CREATE TABLE `tabla_estufas` (
  `codigo_estufa` varchar(20) NOT NULL,
  `codigo_item` varchar(10) NOT NULL,
  `descripcion_item` varchar(100) NOT NULL,
  `cantidad_items` int(11) NOT NULL,
  `costo_total` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci COMMENT='Tabla con items creados';

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`item`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `items`
--
ALTER TABLE `items`
  MODIFY `item` int(11) NOT NULL AUTO_INCREMENT COMMENT 'item del item', AUTO_INCREMENT=14;
--
-- Base de datos: `phpmyadmin`
--
CREATE DATABASE IF NOT EXISTS `phpmyadmin` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;
USE `phpmyadmin`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__bookmark`
--

CREATE TABLE `pma__bookmark` (
  `id` int(10) UNSIGNED NOT NULL,
  `dbase` varchar(255) NOT NULL DEFAULT '',
  `user` varchar(255) NOT NULL DEFAULT '',
  `label` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `query` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Bookmarks';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__central_columns`
--

CREATE TABLE `pma__central_columns` (
  `db_name` varchar(64) NOT NULL,
  `col_name` varchar(64) NOT NULL,
  `col_type` varchar(64) NOT NULL,
  `col_length` text DEFAULT NULL,
  `col_collation` varchar(64) NOT NULL,
  `col_isNull` tinyint(1) NOT NULL,
  `col_extra` varchar(255) DEFAULT '',
  `col_default` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Central list of columns';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__column_info`
--

CREATE TABLE `pma__column_info` (
  `id` int(5) UNSIGNED NOT NULL,
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `column_name` varchar(64) NOT NULL DEFAULT '',
  `comment` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `mimetype` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `transformation` varchar(255) NOT NULL DEFAULT '',
  `transformation_options` varchar(255) NOT NULL DEFAULT '',
  `input_transformation` varchar(255) NOT NULL DEFAULT '',
  `input_transformation_options` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Column information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__designer_settings`
--

CREATE TABLE `pma__designer_settings` (
  `username` varchar(64) NOT NULL,
  `settings_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Settings related to Designer';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__export_templates`
--

CREATE TABLE `pma__export_templates` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) NOT NULL,
  `export_type` varchar(10) NOT NULL,
  `template_name` varchar(64) NOT NULL,
  `template_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved export templates';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__favorite`
--

CREATE TABLE `pma__favorite` (
  `username` varchar(64) NOT NULL,
  `tables` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Favorite tables';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__history`
--

CREATE TABLE `pma__history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(64) NOT NULL DEFAULT '',
  `db` varchar(64) NOT NULL DEFAULT '',
  `table` varchar(64) NOT NULL DEFAULT '',
  `timevalue` timestamp NOT NULL DEFAULT current_timestamp(),
  `sqlquery` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='SQL history for phpMyAdmin';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__navigationhiding`
--

CREATE TABLE `pma__navigationhiding` (
  `username` varchar(64) NOT NULL,
  `item_name` varchar(64) NOT NULL,
  `item_type` varchar(64) NOT NULL,
  `db_name` varchar(64) NOT NULL,
  `table_name` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Hidden items of navigation tree';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__pdf_pages`
--

CREATE TABLE `pma__pdf_pages` (
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `page_nr` int(10) UNSIGNED NOT NULL,
  `page_descr` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='PDF relation pages for phpMyAdmin';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__recent`
--

CREATE TABLE `pma__recent` (
  `username` varchar(64) NOT NULL,
  `tables` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Recently accessed tables';

--
-- Volcado de datos para la tabla `pma__recent`
--

INSERT INTO `pma__recent` (`username`, `tables`) VALUES
('root', '[{\"db\":\"metalcof\",\"table\":\"items\"},{\"db\":\"metalcof\",\"table\":\"tabla_estufas\"},{\"db\":\"metalcof\",\"table\":\"nuevaestufa\"},{\"db\":\"estufas\",\"table\":\"clientes\"},{\"db\":\"estufas\",\"table\":\"Clientes\"}]');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__relation`
--

CREATE TABLE `pma__relation` (
  `master_db` varchar(64) NOT NULL DEFAULT '',
  `master_table` varchar(64) NOT NULL DEFAULT '',
  `master_field` varchar(64) NOT NULL DEFAULT '',
  `foreign_db` varchar(64) NOT NULL DEFAULT '',
  `foreign_table` varchar(64) NOT NULL DEFAULT '',
  `foreign_field` varchar(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Relation table';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__savedsearches`
--

CREATE TABLE `pma__savedsearches` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) NOT NULL DEFAULT '',
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `search_name` varchar(64) NOT NULL DEFAULT '',
  `search_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved searches';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__table_coords`
--

CREATE TABLE `pma__table_coords` (
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `pdf_page_number` int(11) NOT NULL DEFAULT 0,
  `x` float UNSIGNED NOT NULL DEFAULT 0,
  `y` float UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table coordinates for phpMyAdmin PDF output';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__table_info`
--

CREATE TABLE `pma__table_info` (
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `display_field` varchar(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__table_uiprefs`
--

CREATE TABLE `pma__table_uiprefs` (
  `username` varchar(64) NOT NULL,
  `db_name` varchar(64) NOT NULL,
  `table_name` varchar(64) NOT NULL,
  `prefs` text NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Tables'' UI preferences';

--
-- Volcado de datos para la tabla `pma__table_uiprefs`
--

INSERT INTO `pma__table_uiprefs` (`username`, `db_name`, `table_name`, `prefs`, `last_update`) VALUES
('root', 'metalcof', 'nuevaestufa', '{\"CREATE_TIME\":\"2024-08-20 19:48:11\",\"col_order\":[0,1,3,2,4,5,6,7],\"col_visib\":[1,1,1,1,1,1,1,1]}', '2024-08-26 00:51:49');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__tracking`
--

CREATE TABLE `pma__tracking` (
  `db_name` varchar(64) NOT NULL,
  `table_name` varchar(64) NOT NULL,
  `version` int(10) UNSIGNED NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `schema_snapshot` text NOT NULL,
  `schema_sql` text DEFAULT NULL,
  `data_sql` longtext DEFAULT NULL,
  `tracking` set('UPDATE','REPLACE','INSERT','DELETE','TRUNCATE','CREATE DATABASE','ALTER DATABASE','DROP DATABASE','CREATE TABLE','ALTER TABLE','RENAME TABLE','DROP TABLE','CREATE INDEX','DROP INDEX','CREATE VIEW','ALTER VIEW','DROP VIEW') DEFAULT NULL,
  `tracking_active` int(1) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Database changes tracking for phpMyAdmin';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__userconfig`
--

CREATE TABLE `pma__userconfig` (
  `username` varchar(64) NOT NULL,
  `timevalue` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `config_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User preferences storage for phpMyAdmin';

--
-- Volcado de datos para la tabla `pma__userconfig`
--

INSERT INTO `pma__userconfig` (`username`, `timevalue`, `config_data`) VALUES
('root', '2024-10-15 23:54:36', '{\"Console\\/Mode\":\"collapse\",\"lang\":\"es\"}');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__usergroups`
--

CREATE TABLE `pma__usergroups` (
  `usergroup` varchar(64) NOT NULL,
  `tab` varchar(64) NOT NULL,
  `allowed` enum('Y','N') NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User groups with configured menu items';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pma__users`
--

CREATE TABLE `pma__users` (
  `username` varchar(64) NOT NULL,
  `usergroup` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Users and their assignments to user groups';

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `pma__central_columns`
--
ALTER TABLE `pma__central_columns`
  ADD PRIMARY KEY (`db_name`,`col_name`);

--
-- Indices de la tabla `pma__column_info`
--
ALTER TABLE `pma__column_info`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `db_name` (`db_name`,`table_name`,`column_name`);

--
-- Indices de la tabla `pma__designer_settings`
--
ALTER TABLE `pma__designer_settings`
  ADD PRIMARY KEY (`username`);

--
-- Indices de la tabla `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_user_type_template` (`username`,`export_type`,`template_name`);

--
-- Indices de la tabla `pma__favorite`
--
ALTER TABLE `pma__favorite`
  ADD PRIMARY KEY (`username`);

--
-- Indices de la tabla `pma__history`
--
ALTER TABLE `pma__history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`,`db`,`table`,`timevalue`);

--
-- Indices de la tabla `pma__navigationhiding`
--
ALTER TABLE `pma__navigationhiding`
  ADD PRIMARY KEY (`username`,`item_name`,`item_type`,`db_name`,`table_name`);

--
-- Indices de la tabla `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  ADD PRIMARY KEY (`page_nr`),
  ADD KEY `db_name` (`db_name`);

--
-- Indices de la tabla `pma__recent`
--
ALTER TABLE `pma__recent`
  ADD PRIMARY KEY (`username`);

--
-- Indices de la tabla `pma__relation`
--
ALTER TABLE `pma__relation`
  ADD PRIMARY KEY (`master_db`,`master_table`,`master_field`),
  ADD KEY `foreign_field` (`foreign_db`,`foreign_table`);

--
-- Indices de la tabla `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_savedsearches_username_dbname` (`username`,`db_name`,`search_name`);

--
-- Indices de la tabla `pma__table_coords`
--
ALTER TABLE `pma__table_coords`
  ADD PRIMARY KEY (`db_name`,`table_name`,`pdf_page_number`);

--
-- Indices de la tabla `pma__table_info`
--
ALTER TABLE `pma__table_info`
  ADD PRIMARY KEY (`db_name`,`table_name`);

--
-- Indices de la tabla `pma__table_uiprefs`
--
ALTER TABLE `pma__table_uiprefs`
  ADD PRIMARY KEY (`username`,`db_name`,`table_name`);

--
-- Indices de la tabla `pma__tracking`
--
ALTER TABLE `pma__tracking`
  ADD PRIMARY KEY (`db_name`,`table_name`,`version`);

--
-- Indices de la tabla `pma__userconfig`
--
ALTER TABLE `pma__userconfig`
  ADD PRIMARY KEY (`username`);

--
-- Indices de la tabla `pma__usergroups`
--
ALTER TABLE `pma__usergroups`
  ADD PRIMARY KEY (`usergroup`,`tab`,`allowed`);

--
-- Indices de la tabla `pma__users`
--
ALTER TABLE `pma__users`
  ADD PRIMARY KEY (`username`,`usergroup`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `pma__column_info`
--
ALTER TABLE `pma__column_info`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `pma__history`
--
ALTER TABLE `pma__history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  MODIFY `page_nr` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- Base de datos: `test`
--
CREATE DATABASE IF NOT EXISTS `test` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `test`;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

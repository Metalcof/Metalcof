
//document.getElementById("item_agregado").addEventListener("keyup", agregar_item_estufa)
function adicionar_item_estufa()
{
    alert('voy bien')
    let item= document.getElementById('item_agregado').value
    //let lista= document.getElementById('lista')
    let url = "pro/tempo_item_estufa.php"
    let formaDato = new FormData()
    formaDato.append("item_agregado", item)
       fetch(url, 
    {   
        //En esta codigo paso los datos de formulario para realizar consulta sobre la DB y traer todos los items que voy agregar
        method: "POST",
        body: formaDato,
        mode: "cors" //Default cors, no-cors, same-origin
        }).then(res => res.json())
        .then(dato_item => { 
            //item_agregado.style.display = 'block'
            //item_agregado.innerHTML = dato_item
            
    }).catch(err => console.log(err)) 
}


function buscar_item_estufa()
{

    let item= document.getElementById('item_agregado').value
    //let lista= document.getElementById('lista')
    let url = "pro/buscar_item_estufa.php"
    let formaDato = new FormData()
    formaDato.append("item_agregado", item)
       fetch(url, 
    {   
        //En esta codigo paso los datos de formulario para realizar consulta sobre la DB y traer todos los items que voy agregar
        method: "POST",
        body: formaDato,
        mode: "cors" //Default cors, no-cors, same-origin
        }).then(res => res.json())
        .then(dato_item => { 
            //item_agregado.style.display = 'block'
            item_agregado.innerHTML = dato_item
            
    }).catch(err => console.log(err)) 
} 

/* function agregar_item_estufa()
{
    alert('aqui voy');
    let item= document.getElementById('item_agregado').value
    let lista= document.getElementById('lista')
    let url = "pro/buscar_item_estufa.php"
    let formaDato = new FormData()
    formaDato.append("item_agregado", item)
       fetch(url, 
    {
        //En esta codigo paso los datos de formulario para realizar consulta sobre la DB y traer todos los items que voy agregar
        method: "POST",
        body: formaDato,
        mode: "cors" //Default cors, no-cors, same-origin
        }).then(res => res.json())
        .then(dato_item => { 
            lista.style.display = 'block'
            lista.innerHTML = dato_item
            
    }).catch(err => console.log(err)) 
}*/